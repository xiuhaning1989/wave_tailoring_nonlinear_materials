KE_mid=mv_minmax_kinetic_energy_nonlinear_mid./mv_minmax_kinetic_energy_linear_mid;
KE_15=mv_minmax_kinetic_energy_nonlinear_15./mv_minmax_kinetic_energy_linear_15;
KE_19=mv_minmax_kinetic_energy_nonlinear_19./mv_minmax_kinetic_energy_linear_19;
KE_end=mv_minmax_kinetic_energy_nonlinear_end./mv_minmax_kinetic_energy_linear_end;

% KE_mid=KE_mid(1:1000);KE_15=KE_15(1:1000);KE_19=KE_19(1:1000);KE_end=KE_end(1:1000);

L = length(KE_mid);
%take fft
dt = m*1000*M_imp_matrix(13)-m*1000*M_imp_matrix(12);
Fs =1/dt;

NFFT = 2^nextpow2(L); % Next power of 2 from length of y
KE_FFT_mid = fft(KE_mid,NFFT)/L;
KE_FFT_15 = fft(KE_15,NFFT)/L;
KE_FFT_19 = fft(KE_19,NFFT)/L;
KE_FFT_end = fft(KE_end,NFFT)/L;

f = Fs/2*linspace(0,1,NFFT/2+1);
KE_FFT_mid_plot = 2*abs(KE_FFT_mid(1:NFFT/2+1));
KE_FFT_mid_plot_norm = KE_FFT_mid_plot./max(KE_FFT_mid_plot);
KE_FFT_15_plot = 2*abs(KE_FFT_15(1:NFFT/2+1));
KE_FFT_15_plot_norm = KE_FFT_15_plot./max(KE_FFT_15_plot);
KE_FFT_19_plot = 2*abs(KE_FFT_19(1:NFFT/2+1));
KE_FFT_19_plot_norm = KE_FFT_19_plot./max(KE_FFT_19_plot);
KE_FFT_end_plot = 2*abs(KE_FFT_end(1:NFFT/2+1));
KE_FFT_end_plot_norm = KE_FFT_end_plot./max(KE_FFT_end_plot);

figure;
plot(f,smooth(KE_FFT_mid_plot),'k-',LineWidth=2);
hold on;
plot(f,smooth(KE_FFT_15_plot),'b-',LineWidth=1.67);
plot(f,smooth(KE_FFT_19_plot),'r-',LineWidth=1.33);
plot(f,smooth(KE_FFT_end_plot),'g-',LineWidth=1);
xlim([f(2) f(end)])
xlabel('freq [g]')
ylabel('|FFT of KE_{non}/KE_{lin}|')
title('Frequency Domain')
set(gca,'YScale','log')
legend('KE at 10th','KE at 15th','KE at 19th','KE at 20th')
grid on;

%%

% KE_mid=mv_minmax_kinetic_energy_nonlinear_mid./mv_minmax_kinetic_energy_linear_mid;
% KE_15=mv_minmax_kinetic_energy_nonlinear_15./mv_minmax_kinetic_energy_linear_15;
% KE_19=mv_minmax_kinetic_energy_nonlinear_19./mv_minmax_kinetic_energy_linear_19;
% KE_end=mv_minmax_kinetic_energy_nonlinear_end./mv_minmax_kinetic_energy_linear_end;
% 
% L = length(KE_mid);
% %take fft
% dt = c0*V_imp_matrix(13)-c0*V_imp_matrix(12);
% Fs =1/dt;
% 
% NFFT = 2^nextpow2(L); % Next power of 2 from length of y
% KE_FFT_mid = fft(KE_mid,NFFT)/L;
% KE_FFT_15 = fft(KE_15,NFFT)/L;
% KE_FFT_19 = fft(KE_19,NFFT)/L;
% KE_FFT_end = fft(KE_end,NFFT)/L;
% 
% f = Fs/2*linspace(0,1,NFFT/2+1);
% KE_FFT_mid_plot = 2*abs(KE_FFT_mid(1:NFFT/2+1));
% KE_FFT_mid_plot_norm = KE_FFT_mid_plot./max(KE_FFT_mid_plot);
% KE_FFT_15_plot = 2*abs(KE_FFT_15(1:NFFT/2+1));
% KE_FFT_15_plot_norm = KE_FFT_15_plot./max(KE_FFT_15_plot);
% KE_FFT_19_plot = 2*abs(KE_FFT_19(1:NFFT/2+1));
% KE_FFT_19_plot_norm = KE_FFT_19_plot./max(KE_FFT_19_plot);
% KE_FFT_end_plot = 2*abs(KE_FFT_end(1:NFFT/2+1));
% KE_FFT_end_plot_norm = KE_FFT_end_plot./max(KE_FFT_end_plot);
% 
% figure;
% plot(f,smooth(KE_FFT_mid_plot),'k-',LineWidth=2);
% hold on;
% plot(f,smooth(KE_FFT_15_plot),'b-',LineWidth=1.67);
% plot(f,smooth(KE_FFT_19_plot),'r-',LineWidth=1.33);
% plot(f,smooth(KE_FFT_end_plot),'g-',LineWidth=1);
% xlim([f(2) f(end)])
% xlabel('freq [m/s]')
% ylabel('|FFT of KE_{non}/KE_{lin}|')
% title('Frequency Domain')
% set(gca,'YScale','log')
% legend('KE at 10th','KE at 15th','KE at 19th','KE at 20th')
% grid on;