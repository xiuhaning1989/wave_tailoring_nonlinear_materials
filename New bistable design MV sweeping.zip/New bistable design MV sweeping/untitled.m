clear all
clc
load mv_zeta_nonlinear_linear_new.mat

for i=1:51
    dKE_M10(i,:)=diff(log10(mv_minmax_kinetic_energy_nonlinear_end(i,:)./mv_minmax_kinetic_energy_linear_end(i,:)))./...
        diff(1000*m*M_imp_matrix(i,:));%/(M_imp_matrix(1,2)-M_imp_matrix(1,1))/(m);
    dKE_M(i,:)=diff((mv_minmax_kinetic_energy_nonlinear_end(i,:)./mv_minmax_kinetic_energy_linear_end(i,:)))./...
        diff(1000*m*M_imp_matrix(i,:));
end
for j=1:51
    yyy=mv_minmax_kinetic_energy_nonlinear_end(:,j)./mv_minmax_kinetic_energy_linear_end(:,j);
    xxx=log10(yyy);
    dKE_V10(:,j)=diff(xxx,1)./...
        diff(c0*V_imp_matrix(:,j));%/(V_imp_matrix(2,1)-V_imp_matrix(1,1))/c0;
    dKE_V(:,j)=diff(yyy,1)./...
        diff(c0*V_imp_matrix(:,j));
end

figure;pcolor(1000*m*M_imp_matrix,c0*V_imp_matrix,mv_minmax_kinetic_energy_nonlinear_end./mv_minmax_kinetic_energy_linear_end)
set(gca,'colorscale','log')
colormap summer
shading flat
xlabel("Impact mass (g)")
ylabel("Impact velocity (m/s)")
% zlabel("dKE/dM")
xlim([20 79.5]);
ylim([0.64 1.92]);
% zlim([-1,1]);
clim([0.05 1]);
% set(gca,'colorscale','log')
c=colorbar;

figure;pcolor(1000*m*M_imp_matrix(:,1:50),c0*V_imp_matrix(:,1:50),dKE_M)
% set(gca,'colorscale','log')
% set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
% caxis([1e-2 upper_limit]);
colormap jet
xlabel("Impact mass (g)")
ylabel("Impact velocity (m/s)")
% zlabel("dKE/dM")
xlim([20 78.5]);
ylim([0.64 1.92]);
% xticks([20,30,40,50,60,70,80])
% yticks([0.64,0.8,0.96,1.12,1.28,1.44,1.6,1.76,1.92])
% zlim([-1,1]);
clim([-1 1]);
% set(gca,'colorscale','log')
c=colorbar;
c.Label.String = 'dKE/dM';
shading flat
axis equal
axis square

figure;pcolor(1000*m*M_imp_matrix(1:50,:),c0*V_imp_matrix(1:50,:),dKE_V)
% set(gca,'colorscale','log')
% set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
% caxis([1e-2 upper_limit]);
colormap jet
xlabel("Impact mass (g)")
ylabel("Impact velocity (m/s)")
% zlabel("dKE/dV")
xlim([20 79.5]);
ylim([0.64 1.89]);
% xticks([20,30,40,50,60,70,80])
% yticks([0.64,0.8,0.96,1.12,1.28,1.44,1.6,1.76,1.92])
% zlim([-1,1]);
clim([-40 40]);
% set(gca,'colorscale','log')
c=colorbar;
c.Label.String = 'dKE/dV';
shading flat
axis equal
axis square


figure;pcolor(1000*m*M_imp_matrix(:,1:50),c0*V_imp_matrix(:,1:50),dKE_M10)
% set(gca,'colorscale','log')
% set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
% caxis([1e-2 upper_limit]);
colormap jet
xlabel("Impact mass (g)")
ylabel("Impact velocity (m/s)")
% zlabel("dKE/dM")
xlim([20 78.5]);
ylim([0.64 1.92]);
% xticks([20,30,40,50,60,70,80])
% yticks([0.64,0.8,0.96,1.12,1.28,1.44,1.6,1.76,1.92])
% zlim([-1,1]);
clim([-1 1]);
% set(gca,'colorscale','log')
c=colorbar;
c.Label.String = 'dKE/dM';
shading flat
axis equal
axis square

figure;pcolor(1000*m*M_imp_matrix(1:50,:),c0*V_imp_matrix(1:50,:),dKE_V10)
% set(gca,'colorscale','log')
% set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
% caxis([1e-2 upper_limit]);
colormap jet
xlabel("Impact mass (g)")
ylabel("Impact velocity (m/s)")
% zlabel("dKE/dV")
xlim([20 79.5]);
ylim([0.64 1.89]);
% xticks([20,30,40,50,60,70,80])
% yticks([0.64,0.8,0.96,1.12,1.28,1.44,1.6,1.76,1.92])
% zlim([-1,1]);
clim([-40 40]);
% set(gca,'colorscale','log')
c=colorbar;
c.Label.String = 'dKE/dV';
shading flat
axis equal
axis square

%%%

% for i=1:20
%     dKE_32(i,:)=diff(max_kinetic_energy_end2(i,:));
% end
% for j=1:101
%     dKE_22(:,j)=diff(max_kinetic_energy_end2(:,j),1);
% end
% 
% figure;pcolor(C3_2(:,1:100),C2_2(:,1:100),dKE_32)
% % set(gca,'colorscale','log')
% set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
% % caxis([1e-2 upper_limit]);
% colormap jet
% xlabel("c_3")
% ylabel("c_2")
% xlim([0.1,1e4]);
% ylim([0.1,1000]);
% % set(gca,'colorscale','log')
% c=colorbar;
% c.Label.String = 'Max kinetic energy of the center unit cell';
% shading flat
% axis equal
% axis square
% 
% figure;pcolor(C3_2(1:19,:),C2_2(1:19),dKE_22)
% % set(gca,'colorscale','log')
% set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
% % caxis([1e-2 upper_limit]);
% colormap jet
% xlabel("c_3")
% ylabel("c_2")
% xlim([0.1,1e4]);
% ylim([0.1,1000]);
% % set(gca,'colorscale','log')
% c=colorbar;
% c.Label.String = 'Max kinetic energy of the center unit cell';
% shading flat
% axis equal
% axis square

%%

