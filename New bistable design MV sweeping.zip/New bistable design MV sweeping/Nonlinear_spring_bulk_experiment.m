clear all;
% close all
clc
Best_KE_ratio;

N=1;
figure;
for i=1:length(KE_mid)
    c01=1;
    c03=C3_mid(i);%*4^2/12.5^2;
    c02=C2_mid(i);%*4/12.5;
    L=1;
    x=linspace(0,0.1*L,100);
    y=c01*x+c02*x.^2+c03*x.^3;
    plot(x,y,"LineWidth",2)
    hold on;
end
xlabel("Nondimensionl displacement")
ylabel("Nondimensionl force")
grid on;
ylim([-0.1,0.4])
figure;
for i=1:length(KE_end)
    c01=1;
    c03=C3_end(i)*4^2/12.5^2;
    c02=C2_end(i)*4/12.5;
    L=1;
    x=linspace(0,0.2*L,100);
    y=c01*x+c02*x.^2+c03*x.^3;
    plot(x,y,"LineWidth",2)
    hold on;
end
xlabel("Nondimensionl displacement")
ylabel("Nondimensionl force")
grid on;
ylim([-0.1,0.6])

