clc;
clear all;
% close all;


Best_KE_ratio;
R=1;
% C1=1;C2=C2_mid(R);C3=C3_mid(R);
C1=1;C2=C2_end(R);C3=C3_end(R);

%% Initialize the required input parameters (Unit: m)
% Quadrant on which the stress-strain curve is defined

a=0.125;
k1=1045.45;
m=398.8e-3;
c0=a*sqrt(k1/m);

N = 20;                      % number of layers per sample height
m_layer=1;
C_impact =1.2e4; %C_impact1/(a1*K_layer_Linear1)*a1^1.5;
zeta1=0.005;%eta/(2*sqrt(m_layer*K_layer_Linear1));       % nondimensional viscous damping parameter
zeta2=0.003;
%Define impactor condition (mass and velocity, momentum = mass*velocity)
% V0_impactor=0.22;%logspace(-1.4,-0.4,2001);
V0_impactor=logspace(log10(v_end(R))-0.04,log10(v_end(R))+0.04,2501);

V_impactor=V0_impactor;

M_impactor=m_end(R);
M0_impactor=N/2;
for jj=1:length(M_impactor)
    M_imp_matrix(1:length(V_impactor),jj)=M_impactor(jj);
end
for jj=1:length(V_impactor)
    V_imp_matrix(jj,1:length(M_impactor))=V_impactor(jj);
end

% Setup the options for ode45 solver
options_ode45 = [];
options2 = odeset('RelTol',1e-10,'AbsTol',1e-10.*ones(1,2*(N+1)));


%%

[n_M_imp,m_M_imp]=size(M_imp_matrix);
mv_minmax_kinetic_energy_nonlinear_mid=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_nonlinear_end=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_nonlinear_15=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_nonlinear_19=zeros(n_M_imp,m_M_imp);
mv_minmax_maxstrain_nonlinear=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_linear_mid=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_linear_end=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_linear_15=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_linear_19=zeros(n_M_imp,m_M_imp);

% parpool(6); 

for q=1:m_M_imp
    parfor p=1:n_M_imp
        material_info=[m_layer M_imp_matrix(p,q) C_impact zeta1];
        initialvals = zeros(2*(N+1),1);
        initialvals(2) = V_imp_matrix(p,q);      

        % Solve the 1D lattice system with the initial design variables
        % [t, X] = ode45(@(t,x) nonlinear_spring_equation_of_motion(t,x,nonlinear_spring_info,material_info,0),time_range, initialvals, options2);
        nonlinear_spring_info = [C1 C2 C3];
        
        k_f=1000%max(1,1+2*nonlinear_spring_info(2)+3*nonlinear_spring_info(3));
        % Setup the time range for ode45 solver
        f0 = 1/(2*pi)*sqrt(1/M0_impactor);
        dt_cyc0 = 1/f0;
        cycles = 2;
        outputpercycle = 200;
        f = 1/(2*pi)*sqrt(k_f/M0_impactor);
        dt_cyc = 1/f;
        dt = dt_cyc/outputpercycle;
        T = dt_cyc0*cycles;
        downsample = 1e+1;
        time_range = [0 T];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
        [t, X_non] = ode45(@(t,x) impact_equation_of_motion_asymetric(t,x,...
            nonlinear_spring_info,material_info,0),0:dt:T, initialvals, options2);        
        displacement_x=X_non(:,1:2:2*(N+1));
        Relative_disp=displacement_x(:,2:end-1)-displacement_x(:,3:end);
        Relative_disp(:,N)=displacement_x(:,end)-0;
        mv_minmax_maxstrain_nonlinear(p,q)=max(max(Relative_disp));

% figure;pcolor(1:N,t(1:length(t))/sqrt(k1/m),Relative_disp(1:1:length(t),1:N))
%     shading flat
%     colormap jet
%     clim([-0.1,0.07])
%     xlabel('Number of unit cell');
%     ylabel('Time');
%     title 'Displacement of Unit Cell vs Time'
%     c=colorbar;


        velocity_x=X_non(:,2:2:2*(N+1));
        Velocity_mid=velocity_x(:,11);
        Velocity_end=velocity_x(:,end);
        Velocity_15=velocity_x(:,16);
        Velocity_19=velocity_x(:,end-1);
        Kinetic_energy_mid=1/2*Velocity_mid.^2*m_layer;
        Kinetic_energy_end=1/2*Velocity_end.^2*m_layer;
        Kinetic_energy_15=1/2*Velocity_15.^2*m_layer;
        Kinetic_energy_19=1/2*Velocity_19.^2*m_layer;
        max_kinetic_energy_mid=max(Kinetic_energy_mid);
        max_kinetic_energy_end=max(Kinetic_energy_end);
        max_kinetic_energy_15=max(Kinetic_energy_15);
        max_kinetic_energy_19=max(Kinetic_energy_19);
        mv_minmax_kinetic_energy_nonlinear_mid(p,q)=max_kinetic_energy_mid;
        mv_minmax_kinetic_energy_nonlinear_end(p,q)=max_kinetic_energy_end;
        mv_minmax_kinetic_energy_nonlinear_15(p,q)=max_kinetic_energy_15;
        mv_minmax_kinetic_energy_nonlinear_19(p,q)=max_kinetic_energy_19;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
        material_info=[m_layer M_imp_matrix(p,q) C_impact zeta2];
        nonlinear_spring_info = [C1 0 0];
        [t, X_linear] = ode45(@(t,x) impact_equation_of_motion_asymetric(t,x,...
            nonlinear_spring_info,material_info,0),0:dt:T, initialvals, options2);        
        velocity_x=X_linear(:,2:2:2*(N+1));
        Velocity_mid=velocity_x(:,11);
        Velocity_end=velocity_x(:,end);
        Velocity_15=velocity_x(:,16);
        Velocity_19=velocity_x(:,end-1);
        Kinetic_energy_mid=1/2*Velocity_mid.^2*m_layer;
        Kinetic_energy_end=1/2*Velocity_end.^2*m_layer;
        Kinetic_energy_15=1/2*Velocity_15.^2*m_layer;
        Kinetic_energy_19=1/2*Velocity_19.^2*m_layer;
        max_kinetic_energy_mid=max(Kinetic_energy_mid);
        max_kinetic_energy_end=max(Kinetic_energy_end);
        max_kinetic_energy_15=max(Kinetic_energy_15);
        max_kinetic_energy_19=max(Kinetic_energy_19);
        mv_minmax_kinetic_energy_linear_mid(p,q)=max_kinetic_energy_mid;
        mv_minmax_kinetic_energy_linear_end(p,q)=max_kinetic_energy_end;
        mv_minmax_kinetic_energy_linear_15(p,q)=max_kinetic_energy_15;
        mv_minmax_kinetic_energy_linear_19(p,q)=max_kinetic_energy_19;
    end
end

% save('mv_zeta_nonlinear_linear_mid1.mat')

save('mv_zeta_nonlinear_linear_end1_M1_short.mat')

%%
figure;plot(c0*V_imp_matrix,mv_minmax_kinetic_energy_nonlinear_mid./mv_minmax_kinetic_energy_linear_mid,'k-',LineWidth=2)
xlabel("V_{impactor} (m/s)")
ylabel("KE_{non}/KE_{lin}")
set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
hold on;
plot(c0*V_imp_matrix,mv_minmax_kinetic_energy_nonlinear_15./mv_minmax_kinetic_energy_linear_15,'b-',LineWidth=1.67)
plot(c0*V_imp_matrix,mv_minmax_kinetic_energy_nonlinear_19./mv_minmax_kinetic_energy_linear_19,'r-',LineWidth=1.33)
plot(c0*V_imp_matrix,mv_minmax_kinetic_energy_nonlinear_end./mv_minmax_kinetic_energy_linear_end,'g-',LineWidth=1)
legend('KE at 10th','KE at 15th','KE at 19th','KE at 20th')
grid on;

figure;plot(c0*V_imp_matrix,mv_minmax_maxstrain_nonlinear,'k-',LineWidth=2)
xlabel("V_{impactor} (m/s)")
ylabel("Max strain deformation")
% set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
grid on;

%%

% KE_mid=mv_minmax_kinetic_energy_nonlinear_mid./mv_minmax_kinetic_energy_linear_mid;
% KE_15=mv_minmax_kinetic_energy_nonlinear_15./mv_minmax_kinetic_energy_linear_15;
% KE_19=mv_minmax_kinetic_energy_nonlinear_19./mv_minmax_kinetic_energy_linear_19;
% KE_end=mv_minmax_kinetic_energy_nonlinear_end./mv_minmax_kinetic_energy_linear_end;
% 
% L = length(KE_mid);
% %take fft
% dt = c0*V_imp_matrix(13)-c0*V_imp_matrix(12);
% Fs =1/dt;
% 
% NFFT = 2^nextpow2(L); % Next power of 2 from length of y
% KE_FFT_mid = fft(KE_mid,NFFT)/L;
% KE_FFT_15 = fft(KE_15,NFFT)/L;
% KE_FFT_19 = fft(KE_19,NFFT)/L;
% KE_FFT_end = fft(KE_end,NFFT)/L;
% 
% f = Fs/2*linspace(0,1,NFFT/2+1);
% KE_FFT_mid_plot = 2*abs(KE_FFT_mid(1:NFFT/2+1));
% KE_FFT_mid_plot_norm = KE_FFT_mid_plot./max(KE_FFT_mid_plot);
% KE_FFT_15_plot = 2*abs(KE_FFT_15(1:NFFT/2+1));
% KE_FFT_15_plot_norm = KE_FFT_15_plot./max(KE_FFT_15_plot);
% KE_FFT_19_plot = 2*abs(KE_FFT_19(1:NFFT/2+1));
% KE_FFT_19_plot_norm = KE_FFT_19_plot./max(KE_FFT_19_plot);
% KE_FFT_end_plot = 2*abs(KE_FFT_end(1:NFFT/2+1));
% KE_FFT_end_plot_norm = KE_FFT_end_plot./max(KE_FFT_end_plot);
% 
% figure;
% plot(f,smooth(KE_FFT_mid_plot),'k-',LineWidth=2);
% hold on;
% plot(f,smooth(KE_FFT_15_plot),'b-',LineWidth=1.67);
% plot(f,smooth(KE_FFT_19_plot),'r-',LineWidth=1.33);
% plot(f,smooth(KE_FFT_end_plot),'g-',LineWidth=1);
% xlim([f(2) f(end)])
% xlabel('freq [m/s]')
% ylabel('|FFT of KE_{non}/KE_{lin}|')
% title('Frequency Domain')
% set(gca,'YScale','log')
% legend('KE at 10th','KE at 15th','KE at 19th','KE at 20th')
% grid on;
