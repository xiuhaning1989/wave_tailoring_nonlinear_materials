clc;
clear all;
% close all;


Best_KE_ratio;
C3=1781.748;%2238;%199.53;
C2=-87.261;%-101.8;%-29.11;
C1=1;
%% Initialize the required input parameters (Unit: m)
% Quadrant on which the stress-strain curve is defined

a=0.125;
k1=1045.45;
k2=1059.8;
m=398.8e-3;
m2=400.4e-3;
c0=a*sqrt(k1/m);
c_lin=a*sqrt(k2/m2);

N = 20;                      % number of layers per sample height
m_layer=1;
C_impact =1.2e4; %C_impact1/(a1*K_layer_Linear1)*a1^1.5;
zeta1=0.005;%eta/(2*sqrt(m_layer*K_layer_Linear1));       % nondimensional viscous damping parameter
zeta2=0.003;
%Define impactor condition (mass and velocity, momentum = mass*velocity)
V0_impactor=linspace(0.1,0.3,51);

V_impactor=V0_impactor;

M_impactor=linspace(0.05,0.2,51);
M0_impactor=N/2;
for jj=1:length(M_impactor)
    M_imp_matrix(1:length(V_impactor),jj)=M_impactor(jj);
end
for jj=1:length(V_impactor)
    V_imp_matrix(jj,1:length(M_impactor))=V_impactor(jj);
end

% Setup the options for ode45 solver
options_ode45 = [];
options2 = odeset('RelTol',1e-10,'AbsTol',1e-10.*ones(1,2*(N+1)));


%%

[n_M_imp,m_M_imp]=size(M_imp_matrix);
mv_minmax_kinetic_energy_nonlinear_mid=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_nonlinear_end=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_nonlinear_15=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_nonlinear_19=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_linear_mid=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_linear_end=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_linear_15=zeros(n_M_imp,m_M_imp);
mv_minmax_kinetic_energy_linear_19=zeros(n_M_imp,m_M_imp);

% parpool(6); 

parfor q=1:m_M_imp
    for p=1:n_M_imp
        material_info=[m_layer M_imp_matrix(p,q) C_impact zeta1];
        initialvals = zeros(2*(N+1),1);
        initialvals(2) = V_imp_matrix(p,q);      

        % Solve the 1D lattice system with the initial design variables
        % [t, X] = ode45(@(t,x) nonlinear_spring_equation_of_motion(t,x,nonlinear_spring_info,material_info,0),time_range, initialvals, options2);
        nonlinear_spring_info = [C1 C2 C3];
        
        k_f=100;%max(1,1+2*nonlinear_spring_info(2)+3*nonlinear_spring_info(3));
        % Setup the time range for ode45 solver
        f0 = 1/(2*pi)*sqrt(1/M0_impactor);
        dt_cyc0 = 1/f0;
        cycles = 4;
        outputpercycle = 100;
        f = 1/(2*pi)*sqrt(k_f/M0_impactor);
        dt_cyc = 1/f;
        dt = dt_cyc/outputpercycle;
        T = dt_cyc0*cycles;
        downsample = 1e+1;
        time_range = [0 T];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
        [t, X_non] = ode45(@(t,x) impact_equation_of_motion_asymetric(t,x,...
            nonlinear_spring_info,material_info,0),0:dt:T, initialvals, options2);        
        velocity_x=X_non(:,2:2:2*(N+1));
        Velocity_mid=velocity_x(:,11);
        Velocity_end=velocity_x(:,end);
        Velocity_15=velocity_x(:,16);
        Velocity_19=velocity_x(:,end-1);
        Kinetic_energy_mid=1/2*Velocity_mid.^2*m_layer;
        Kinetic_energy_end=1/2*Velocity_end.^2*m_layer;
        Kinetic_energy_15=1/2*Velocity_15.^2*m_layer;
        Kinetic_energy_19=1/2*Velocity_19.^2*m_layer;
        max_kinetic_energy_mid=max(Kinetic_energy_mid);
        max_kinetic_energy_end=max(Kinetic_energy_end);
        max_kinetic_energy_15=max(Kinetic_energy_15);
        max_kinetic_energy_19=max(Kinetic_energy_19);
        mv_minmax_kinetic_energy_nonlinear_mid(p,q)=max_kinetic_energy_mid;
        mv_minmax_kinetic_energy_nonlinear_end(p,q)=max_kinetic_energy_end;
        mv_minmax_kinetic_energy_nonlinear_15(p,q)=max_kinetic_energy_15;
        mv_minmax_kinetic_energy_nonlinear_19(p,q)=max_kinetic_energy_19;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
        material_info=[m_layer M_imp_matrix(p,q) C_impact zeta2];
        nonlinear_spring_info = [C1 0 0];
        [t, X_linear] = ode45(@(t,x) impact_equation_of_motion_asymetric(t,x,...
            nonlinear_spring_info,material_info,0),0:dt:T, initialvals, options2);        
        velocity_x=X_linear(:,2:2:2*(N+1));
        Velocity_mid=velocity_x(:,11);
        Velocity_end=velocity_x(:,end);
        Velocity_15=velocity_x(:,16);
        Velocity_19=velocity_x(:,end-1);
        Kinetic_energy_mid=1/2*Velocity_mid.^2*m_layer;
        Kinetic_energy_end=1/2*Velocity_end.^2*m_layer;
        Kinetic_energy_15=1/2*Velocity_15.^2*m_layer;
        Kinetic_energy_19=1/2*Velocity_19.^2*m_layer;
        max_kinetic_energy_mid=max(Kinetic_energy_mid);
        max_kinetic_energy_end=max(Kinetic_energy_end);
        max_kinetic_energy_15=max(Kinetic_energy_15);
        max_kinetic_energy_19=max(Kinetic_energy_19);
        mv_minmax_kinetic_energy_linear_mid(p,q)=max_kinetic_energy_mid;
        mv_minmax_kinetic_energy_linear_end(p,q)=max_kinetic_energy_end;
        mv_minmax_kinetic_energy_linear_15(p,q)=max_kinetic_energy_15;
        mv_minmax_kinetic_energy_linear_19(p,q)=max_kinetic_energy_19;
    end
end

% save('mv_zeta_nonlinear_linear_mid1.mat')

save('mv_zeta_nonlinear_linear_new.mat')

%%
figure;pcolor(1000*M_imp_matrix*m,c0*V_imp_matrix,mv_minmax_kinetic_energy_nonlinear_mid./mv_minmax_kinetic_energy_linear_mid)
clim([0.06 1]);
xlim([9.3 58.9]);
ylim([0.765 7.65]);
xticks([10,20,30,40,50,58])
yticks([0.8 1 2 3 4 5 6 7 7.6])
colormap jet
shading flat
set(gca,'colorscale','log')
% set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
xlabel("M_{impactor} (g)")
ylabel("V_{impactor} (m/s)")
c=colorbar;
c.Ticks = [0.06 0.08 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];
axis square
c.Label.String = 'Best ratio of half-way kinetic energy';

figure;pcolor(1000*M_imp_matrix*m,c0*V_imp_matrix,mv_minmax_kinetic_energy_nonlinear_end./mv_minmax_kinetic_energy_linear_end)
clim([0.06 1]);
xlim([20 80]);
ylim([0.64 1.92]);
xticks([20,30,40,50,60,70,80])
yticks([0.64,0.8,0.96,1.12,1.28,1.44,1.6,1.76,1.92])
colormap jet
shading flat
set(gca,'colorscale','log')
% set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
xlabel("M_{impactor} (g)")
ylabel("V_{impactor} (m/s)")
c=colorbar;
c.Ticks = [0.04 0.08 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];
axis square
c.Label.String = 'Best ratio of last unit cell--kinetic energy';

figure;pcolor(1000*M_imp_matrix*m,c0*V_imp_matrix,mv_minmax_kinetic_energy_nonlinear_15./mv_minmax_kinetic_energy_linear_15)
clim([0.06 1]);
xlim([9.3 58.9]);
ylim([0.8 7.5]);
xticks([10,20,30,40,50,58])
yticks([0.8 1 2 3 4 5 6 7 7.6])
colormap jet
shading flat
set(gca,'colorscale','log')
% set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
xlabel("M_{impactor} (g)")
ylabel("V_{impactor} (m/s)")
c=colorbar;
c.Ticks = [0.06 0.08 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];
axis square
c.Label.String = 'Best ratio of 15th unit cell--kinetic energy';

figure;pcolor(1000*M_imp_matrix*m,c0*V_imp_matrix,mv_minmax_kinetic_energy_nonlinear_19./mv_minmax_kinetic_energy_linear_19)
clim([0.06 1]);
xlim([9.3 58.9]);
ylim([0.765 7.65]);
xticks([10,20,30,40,50,58])
yticks([0.8 1 2 3 4 5 6 7 7.6])
colormap jet
shading flat
set(gca,'colorscale','log')
% set(gca, 'YScale', 'log');
% set(gca, 'XScale', 'log');
xlabel("M_{impactor} (g)")
ylabel("V_{impactor} (m/s)")
c=colorbar;
c.Ticks = [0.06 0.08 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];
axis square
c.Label.String = 'Best ratio of 19th unit cell--kinetic energy';