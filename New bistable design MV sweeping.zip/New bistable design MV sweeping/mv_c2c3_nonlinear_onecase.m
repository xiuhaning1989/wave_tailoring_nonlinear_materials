clc;
clear all;
% close all;


Best_KE_ratio;

%% Initialize the required input parameters (Unit: m)
% Quadrant on which the stress-strain curve is defined
a=0.125;
k1=3500;
k2=3200;
m=0.148;
c0=a*sqrt(k1/m);
c_lin=a*sqrt(k2/m);

C1=1;
N = 20;                      % number of layers per sample height
m_layer=1;
C_impact =1.2e4; %C_impact1/(a1*K_layer_Linear1)*a1^1.5;
zeta=0.005;%eta/(2*sqrt(m_layer*K_layer_Linear1));       % nondimensional viscous damping parameter
M0_impactor=N/2;
%Define impactor condition (mass and velocity, momentum = mass*velocity)
% Setup the options for ode45 solver
options_ode45 = [];
options2 = odeset('RelTol',1e-10,'AbsTol',1e-10.*ones(1,2*(N+1)));
for i=1%:length(KE_mid)
        nonlinear_spring_info = [C1 C2_mid(i) C3_mid(i)];
        material_info=[m_layer m_mid(i) C_impact zeta];
        initialvals = zeros(2*(N+1),1);
        initialvals(2) = v_mid(i);

        k_f=max(1,1+2*nonlinear_spring_info(2)+3*nonlinear_spring_info(3));
        % Setup the time range for ode45 solver
        f0 = 1/(2*pi)*sqrt(1/M0_impactor);
        dt_cyc0 = 1/f0;
        cycles = 5;
        outputpercycle = 1000;
        f = 1/(2*pi)*sqrt(k_f/M0_impactor);
        dt_cyc = 1/f;
        dt = dt_cyc/outputpercycle;
        T = dt_cyc0*cycles;
        downsample = 1e+1;
        time_range = [0 T];


        [t, X] = ode45(@(t,x) impact_equation_of_motion_asymetric(t,x,...
            nonlinear_spring_info,material_info,0),0:dt:T, initialvals, options2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        displacement_x=X(:,1:2:2*(N+1));
        Relative_disp=displacement_x(:,2:end-1)-displacement_x(:,3:end);
        Relative_disp(:,N)=displacement_x(:,end)-0;
        figure;pcolor(1:N,t(1:length(t))/sqrt(k1/m),Relative_disp(1:1:length(t),1:N))
    shading flat
    colormap jet
    % caxis([-0.05,0.02])
    xlabel('Number of rotor');
    ylabel('Time');
    title 'Displacement of Rotor vs Time'
    c=colorbar;
end
    


%%


for i=1:length(KE_end)
    nonlinear_spring_info = [C1 C2_end(i) C3_end(i)];
    material_info=[m_layer m_end(i) C_impact zeta];
    initialvals = zeros(2*(N+1),1);
    initialvals(2) = v_end(i)*0.5;

    k_f=max(1,1+2*nonlinear_spring_info(2)+3*nonlinear_spring_info(3));
        % Setup the time range for ode45 solver
    f0 = 1/(2*pi)*sqrt(1/M0_impactor);
    dt_cyc0 = 1/f0;
    cycles = 5;
    outputpercycle = 200;
    f = 1/(2*pi)*sqrt(k_f/M0_impactor);
    dt_cyc = 1/f;
    dt = dt_cyc/outputpercycle;
    T = dt_cyc0*cycles;
    downsample = 1e+1;
    time_range = [0 T];


    [t, X_non] = ode45(@(t,x) impact_equation_of_motion_asymetric(t,x,...
            nonlinear_spring_info,material_info,0),0:dt:T, initialvals, options2);        
        displacement_x=X_non(:,1:2:2*(N+1));
        Relative_disp=displacement_x(:,2:end-1)-displacement_x(:,3:end);
        Relative_disp(:,N)=displacement_x(:,end)-0;
        
    max(max(Relative_disp))
    figure;pcolor(1:N,t(1:length(t))/sqrt(k1/m),Relative_disp(1:1:length(t),1:N))
    shading flat
    colormap jet
    clim([-0.1,0.07])
    xlabel('Number of unit cell');
    ylabel('Time');
    title 'Displacement of Unit Cell vs Time'
    c=colorbar;
end
    
% 





