clear all
clc

load hexagon_101_31_impact_hardening.mat
filename1 = 'hexagon_101_31_impact_hardening.gif';

% load hexagon_101_31_impact_softening.mat
% filename1 = 'hexagon_101_31_impact_softening.gif';
% plot(atom(:,3),atom(:,4),'o','MarkerEdgeColor', 'blue', 'LineWidth', 2, 'MarkerSize', 15,'MarkerFaceColor','cyan');
%%
% mymap = [1 0 0;1 0.05 0.05;1,0.1,0.1;1 0.2 0.2; 1 0.3 0.3;1 0.4 0.4;1 0.5 0.5;1 0.6 0.6;1 0.7 0.7;
%     1 0.8 0.8;1 0.85 0.85;1 0.9 0.9;1 0.95 0.95;1 1 1;0.95 0.95 1;0.9 0.9 1;0.85 0.85 1;0.8 0.8 1;
%     0.7 0.7 1;0.6 0.6 1;0.5 0.5 1;0.4 0.4 1;0.3 0.3 1;0.2 0.2 1;0.1 0.1 1;0.05 0.05 1; 0 0 1];
% mymap=flip(mymap);

%%
T=t(1:fix(length(t)/300):fix(length(t)/300)*220);

x_unit=atom(:,3)'+displacement_x_non;
y_unit=atom(:,4)'+displacement_y_non;
phi_unit=atom(:,5)'+displacement_rotation_non;              
% Kinetic_energy=0.5*mass*(velocity_x_non.^2+velocity_y_non.^2)+0.5*Inertia*velocity_rotation_non.^2;

figure(1)
% colormap jet;
% set(gcf, 'position', [50 50 2550 750]);%[50 50 2550 200]
% M = moviein(length(T));
for tt=1:length(T) 
    time0=find(abs(t-T(tt))<1e-5);
%     X=[];Y=[];
%     C_normal=[];C_shear=[];
%     for i=1:3*nx+2
%         if mod(i,2)==1
%         for j = 2 :2: 2*ny 
%             Uij_entire=zeros(21,1);
%             p_entire=zeros(7,1);q_entire=zeros(7,1);r_entire=zeros(7,1);
%             X_unit=[];Y_unit=[];xt=[];yt=[];Normal=[];Shear=[];
%             result = strcat(num2str(i),num2str(j),num2str(1));   Uij_entire(1) = str2double(result);
%             result = strcat(num2str(i),num2str(j),num2str(2));   Uij_entire(2) = str2double(result);
%             result = strcat(num2str(i),num2str(j),num2str(3));   Uij_entire(3) = str2double(result);
%             result = strcat(num2str(i-2),num2str(j),num2str(1));   Uij_entire(4) = str2double(result);
%             result = strcat(num2str(i-2),num2str(j),num2str(2));   Uij_entire(5) = str2double(result);
%             result = strcat(num2str(i-2),num2str(j),num2str(3));   Uij_entire(6) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j-1),num2str(1));   Uij_entire(7) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j-1),num2str(2));   Uij_entire(8) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j-1),num2str(3));   Uij_entire(9) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j+1),num2str(1));   Uij_entire(10) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j+1),num2str(2));   Uij_entire(11) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j+1),num2str(3));   Uij_entire(12) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j-1),num2str(1));   Uij_entire(13) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j-1),num2str(2));   Uij_entire(14) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j-1),num2str(3));   Uij_entire(15) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j+1),num2str(1));   Uij_entire(16) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j+1),num2str(2));   Uij_entire(17) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j+1),num2str(3));   Uij_entire(18) = str2double(result);
%             result = strcat(num2str(i+2),num2str(j),num2str(1));   Uij_entire(19) = str2double(result);
%             result = strcat(num2str(i+2),num2str(j),num2str(2));   Uij_entire(20) = str2double(result);
%             result = strcat(num2str(i+2),num2str(j),num2str(3));   Uij_entire(21) = str2double(result);
%             if j<10
%                 Uij_entire=Uij_entire/1e2;
%             elseif j<100
%                 Uij_entire=Uij_entire/1e3;
%             else
%                 Uij_entire=Uij_entire/1e4;
%             end
%             if j-1==9 || j-1==99
%                 Uij_entire(7:9)=Uij_entire(7:9)*10;Uij_entire(13:15)=Uij_entire(13:15)*10;
%             end
%             for aa=1:7
%                 if ~isempty(find(abs(U_entire_name-Uij_entire(3*aa))<1e-4, 1))        
%                     p_entire(aa)=find(abs(U_entire_name-Uij_entire(3*aa-2))<1e-4);
%                     q_entire(aa)=find(abs(U_entire_name-Uij_entire(3*aa-1))<1e-4);
%                     r_entire(aa)=find(abs(U_entire_name-Uij_entire(3*aa))<1e-4);
%                 end
%             end
% 
%             num=find(p_entire~=0);
%             for k=2:length(num)
%                 X_unit=[X_unit;x_unit(time0,(p_entire(1)+2)/3);x_unit(time0,(p_entire(num(k))+2)/3)];
%                 Y_unit=[Y_unit;y_unit(time0,(q_entire(1)+1)/3);y_unit(time0,(q_entire(num(k))+1)/3)];
%                 xt = [xt;x_unit(time0,(p_entire(1)+2)/3);x_unit(time0,(p_entire(num(k))+2)/3);NaN];                      
%                 yt = [yt;y_unit(time0,(q_entire(1)+1)/3);y_unit(time0,(q_entire(num(k))+1)/3);NaN];   
%                 Normal=[Normal; normal_force(displacement_x_non(time0,(p_entire(1)+2)/3),displacement_y_non(time0,(q_entire(1)+1)/3),displacement_rotation_non(time0,r_entire(1)/3),...
%                     displacement_x_non(time0,(p_entire(num(k))+2)/3),displacement_y_non(time0,(q_entire(num(k))+1)/3),displacement_rotation_non(time0,r_entire(num(k))/3),...
%                     [geometry_config(num(k)-1),geometry_config(end)],coefficients);normal_force(displacement_x_non(time0,(p_entire(1)+2)/3),displacement_y_non(time0,(q_entire(1)+1)/3),displacement_rotation_non(time0,r_entire(1)/3),...
%                     displacement_x_non(time0,(p_entire(num(k))+2)/3),displacement_y_non(time0,(q_entire(num(k))+1)/3),displacement_rotation_non(time0,r_entire(num(k))/3),...
%                     [geometry_config(num(k)-1),geometry_config(end)],coefficients);NaN];
%                 Shear=[Shear;shear_force(displacement_x_non(time0,(p_entire(1)+2)/3),displacement_y_non(time0,(q_entire(1)+1)/3),displacement_rotation_non(time0,r_entire(1)/3),...
%                     displacement_x_non(time0,(p_entire(num(k))+2)/3),displacement_y_non(time0,(q_entire(num(k))+1)/3),displacement_rotation_non(time0,r_entire(num(k))/3),...
%                     [geometry_config(num(k)-1),geometry_config(end)],coefficients);shear_force(displacement_x_non(time0,(p_entire(1)+2)/3),displacement_y_non(time0,(q_entire(1)+1)/3),displacement_rotation_non(time0,r_entire(1)/3),...
%                     displacement_x_non(time0,(p_entire(num(k))+2)/3),displacement_y_non(time0,(q_entire(num(k))+1)/3),displacement_rotation_non(time0,r_entire(num(k))/3),...
%                     [geometry_config(num(k)-1),geometry_config(end)],coefficients);NaN];
%             end
%             X=[X;xt,xt];
%             Y=[Y;yt,yt];  
%             C_normal=[C_normal;Normal, Normal] ;                         %// replicate column vector "c"
%             C_shear=[C_shear;Shear, Shear] ;                         %// replicate column vector "c"            
%         end
%         else
% 
%         for j = 1 :2: 2*ny+1 
%             Uij_entire=zeros(21,1);
%             p_entire=zeros(7,1);q_entire=zeros(7,1);r_entire=zeros(7,1);
%             X_unit=[];Y_unit=[];xt=[];yt=[];Normal=[];Shear=[];
%             result = strcat(num2str(i),num2str(j),num2str(1));   Uij_entire(1) = str2double(result);
%             result = strcat(num2str(i),num2str(j),num2str(2));   Uij_entire(2) = str2double(result);
%             result = strcat(num2str(i),num2str(j),num2str(3));   Uij_entire(3) = str2double(result);
%             result = strcat(num2str(i-2),num2str(j),num2str(1));   Uij_entire(4) = str2double(result);
%             result = strcat(num2str(i-2),num2str(j),num2str(2));   Uij_entire(5) = str2double(result);
%             result = strcat(num2str(i-2),num2str(j),num2str(3));   Uij_entire(6) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j-1),num2str(1));   Uij_entire(7) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j-1),num2str(2));   Uij_entire(8) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j-1),num2str(3));   Uij_entire(9) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j+1),num2str(1));   Uij_entire(10) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j+1),num2str(2));   Uij_entire(11) = str2double(result);
%             result = strcat(num2str(i-1),num2str(j+1),num2str(3));   Uij_entire(12) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j-1),num2str(1));   Uij_entire(13) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j-1),num2str(2));   Uij_entire(14) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j-1),num2str(3));   Uij_entire(15) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j+1),num2str(1));   Uij_entire(16) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j+1),num2str(2));   Uij_entire(17) = str2double(result);
%             result = strcat(num2str(i+1),num2str(j+1),num2str(3));   Uij_entire(18) = str2double(result);
%             result = strcat(num2str(i+2),num2str(j),num2str(1));   Uij_entire(19) = str2double(result);
%             result = strcat(num2str(i+2),num2str(j),num2str(2));   Uij_entire(20) = str2double(result);
%             result = strcat(num2str(i+2),num2str(j),num2str(3));   Uij_entire(21) = str2double(result);
%             if j<10
%                 Uij_entire=Uij_entire/1e2;
%             elseif j<100
%                 Uij_entire=Uij_entire/1e3;
%             else
%                 Uij_entire=Uij_entire/1e4;
%             end
%             if j-1==9 || j-1==99
%                 Uij_entire(7:9)=Uij_entire(7:9)*10;Uij_entire(13:15)=Uij_entire(13:15)*10;
%             end
%             for aa=1:7
%                 if ~isempty(find(abs(U_entire_name-Uij_entire(3*aa))<1e-4, 1))        
%                     p_entire(aa)=find(abs(U_entire_name-Uij_entire(3*aa-2))<1e-4);
%                     q_entire(aa)=find(abs(U_entire_name-Uij_entire(3*aa-1))<1e-4);
%                     r_entire(aa)=find(abs(U_entire_name-Uij_entire(3*aa))<1e-4);
%                 end
%             end
% 
%             num=find(p_entire~=0);
%             for k=2:length(num)
%                 X_unit=[X_unit;x_unit(time0,(p_entire(1)+2)/3);x_unit(time0,(p_entire(num(k))+2)/3)];
%                 Y_unit=[Y_unit;y_unit(time0,(q_entire(1)+1)/3);y_unit(time0,(q_entire(num(k))+1)/3)];
%                 xt = [xt;x_unit(time0,(p_entire(1)+2)/3);x_unit(time0,(p_entire(num(k))+2)/3);NaN];                      
%                 yt = [yt;y_unit(time0,(q_entire(1)+1)/3);y_unit(time0,(q_entire(num(k))+1)/3);NaN];   
%                 Normal=[Normal; normal_force(displacement_x_non(time0,(p_entire(1)+2)/3),displacement_y_non(time0,(q_entire(1)+1)/3),displacement_rotation_non(time0,r_entire(1)/3),...
%                     displacement_x_non(time0,(p_entire(num(k))+2)/3),displacement_y_non(time0,(q_entire(num(k))+1)/3),displacement_rotation_non(time0,r_entire(num(k))/3),...
%                     [geometry_config(num(k)-1),geometry_config(end)],coefficients);normal_force(displacement_x_non(time0,(p_entire(1)+2)/3),displacement_y_non(time0,(q_entire(1)+1)/3),displacement_rotation_non(time0,r_entire(1)/3),...
%                     displacement_x_non(time0,(p_entire(num(k))+2)/3),displacement_y_non(time0,(q_entire(num(k))+1)/3),displacement_rotation_non(time0,r_entire(num(k))/3),...
%                     [geometry_config(num(k)-1),geometry_config(end)],coefficients);NaN];
%                 Shear=[Shear;shear_force(displacement_x_non(time0,(p_entire(1)+2)/3),displacement_y_non(time0,(q_entire(1)+1)/3),displacement_rotation_non(time0,r_entire(1)/3),...
%                     displacement_x_non(time0,(p_entire(num(k))+2)/3),displacement_y_non(time0,(q_entire(num(k))+1)/3),displacement_rotation_non(time0,r_entire(num(k))/3),...
%                     [geometry_config(num(k)-1),geometry_config(end)],coefficients);shear_force(displacement_x_non(time0,(p_entire(1)+2)/3),displacement_y_non(time0,(q_entire(1)+1)/3),displacement_rotation_non(time0,r_entire(1)/3),...
%                     displacement_x_non(time0,(p_entire(num(k))+2)/3),displacement_y_non(time0,(q_entire(num(k))+1)/3),displacement_rotation_non(time0,r_entire(num(k))/3),...
%                     [geometry_config(num(k)-1),geometry_config(end)],coefficients);NaN];
%             end
%             X=[X;xt,xt];
%             Y=[Y;yt,yt];  
%             C_normal=[C_normal;Normal, Normal] ;                         %// replicate column vector "c"
%             C_shear=[C_shear;Shear, Shear] ;                         %// replicate column vector "c"
%             
%         end
%         end
%     end

    Kinetic_energy=0.5*mass*(velocity_x_non(time0,:).^2+velocity_y_non(time0,:).^2)+0.5*Inertia*velocity_rotation_non(time0,:).^2;
    
%     plot(atom(:,3),atom(:,4),'o--','Color', 'y','MarkerEdgeColor', [0.7 0.7 0.7], 'LineWidth', 0.5, 'MarkerSize', 5,'MarkerFaceColor',[0.7 0.7 0.7]);hold on;
    plot(0,0);hold on;
%     Z = zeros(size(X)) ;                %// Z plane = 0
%     plot(X,Y,'k-','LineWidth',0.75);
%     surf(X,Y,Z,C_shear,'EdgeColor','flat','FaceColor','none','LineWidth',2);
%     surf(X,Y,Z,C_normal,'EdgeColor','flat','FaceColor','none','LineWidth',2);
%     cmap_pos = autumn(60);  % For positive values (summer colormap)
%     cmap_neg = summer(60);  % For negative values (autumn colormap)
%     cmap = [cmap_neg; flipud(cmap_pos)];
%     colormap (cmap)
   
%     scatter(x_unit(time0,:),y_unit(time0,:),27,velocity_x_non(time0,:),'filled');
    scatter(x_unit(time0,:),y_unit(time0,:),30,Kinetic_energy/1*mass*0.5^2,'filled');
    colormap jet
    colorbar;
    hold off;
    axis equal  
    grid on;

    xlim([-1 27])
    ylim([-1 51]) 
%     xlim([-0.5 4])
%     ylim([-0.5 2.5]) 
    clim([0.99e-6,1e-2])
%     clim([-0.1,0.1])
    set(gca,'colorscale','log')
    c.Label.String = 'KE of each particle';

    text(8,52,['Time = ' num2str(T(tt),'%.2f')],'FontSize',14)
%     text(1.2,2.65,['Time = ' num2str(T(tt),'%.2f')],'FontSize',14)
    f1 = getframe(gcf); 
        imind1 = frame2im(f1); 
        [imind1,cm1] = rgb2ind(imind1,256); 
    if tt == 1 
        imwrite(imind1,cm1,filename1,'gif', 'Loopcount',500,'DelayTime',0); 
    else
        imwrite(imind1,cm1,filename1,'gif','WriteMode','append','DelayTime',0.2);
    end

end



















%%

function y=shear_force(ux0,uy0,phi0,ux,uy,phi,geometry_config,coefficients)

c31=coefficients(2);c22=coefficients(3);c13=coefficients(4);
c21=coefficients(6);c12=coefficients(7);c11=coefficients(9);
c04=coefficients(10);c03=coefficients(11);c02=coefficients(12);

dl=normal_distance(ux0,uy0,ux,uy,geometry_config);
ds=tangential_distance(ux0,uy0,phi0,ux,uy,phi,geometry_config);

y=c31*dl^3+c22*dl^2*ds+c13*dl*ds^2+c04*ds^3+c21*dl^2+c12*dl*ds+c03*ds^2+c11*dl+c02*ds;

end

%%

function y=normal_force(ux0,uy0,phi0,ux,uy,phi,geometry_config,coefficients)

c31=coefficients(2);c22=coefficients(3);c13=coefficients(4);
c21=coefficients(6);c12=coefficients(7);c11=coefficients(9);
c40=coefficients(1);c30=coefficients(5);c20=coefficients(8);

dl=normal_distance(ux0,uy0,ux,uy,geometry_config);
ds=tangential_distance(ux0,uy0,phi0,ux,uy,phi,geometry_config);

y=c40*dl^3+c31*dl^2*ds+c22*dl*ds^2+c13*ds^3+c30*dl^2+c21*dl*ds+c12*ds^2+c20*dl+c11*ds;

end

%%

function y=normal_distance(ux0,uy0,ux,uy,geometry_config)

l=geometry_config(end);theta=geometry_config(1);

y=sqrt((l*cos(theta)+ux-ux0)^2+(l*sin(theta)+uy-uy0)^2)-l;

end

%%

function y=tangential_distance(ux0,uy0,phi0,ux,uy,phi,geometry_config)

l=geometry_config(end);theta=geometry_config(1);
sgn_1=sign(l*sin(theta)*(ux-ux0)+l*cos(theta)*(-uy+uy0));

y=abs((tan(theta)*ux0-uy0-tan(theta)*(l*cos(theta)+ux)+l*sin(theta)+uy))...
    /sqrt(1+tan(theta)^2)*sgn_1+l*(sin(phi0)+sin(phi))/2;

end

