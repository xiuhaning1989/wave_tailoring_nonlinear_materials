clear all;
clc

load m05v1_zeta001.mat

upper_limit=10;

max_kinetic_energy_end1=log10(max_kinetic_energy_end(1:81,:)/0.0364557763080379);
% log_max_c2=diff(max_kinetic_energy_end1,1,1);
% log_max_c3=diff(max_kinetic_energy_end1,1,2);

log_max_c2=diff(max_kinetic_energy_end1,1,1)./diff(C2_1,1,1);
log_max_c3=diff(max_kinetic_energy_end1,1,2)./diff(C3_1,1,2);

logC3_1=log10(C3_1);logC3_2=log10(C3_2);
logC2_1=log10(C2_1);logC2_2=log10(C2_2(2:end,:));
C21=-10.^logC2_1;


logC3=[logC3_1;logC3_2];logC2=[logC2_1;C2_2(1,:);logC2_2];


%%

figure;pcolor(C3_1(1:80,:),C2_1(1:80,:),log_max_c2)
clim([-10 10]);
colormap jet
shading flat
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
xlabel("c_3")
ylabel("c_2")
xlim([1 15]);
ylim([-10,-1]);
c=colorbar;
% set(gca,'colorscale','log')
c.Label.String = 'Max kinetic energy of the center unit cell';
axis square
hold on;
plot([9.65],[-5.88],'p', 'MarkerSize', 20, 'MarkerFaceColor', 'r', 'MarkerEdgeColor', 'k')
plot([11],[-6.6],'-^', 'MarkerSize', 10, 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'k')
plot([6.75],[-5.36],'s', 'MarkerSize', 10, 'MarkerFaceColor', 'm', 'MarkerEdgeColor', 'k')

figure;pcolor(C3_1(:,1:100),C2_1(:,1:100),log_max_c3)
clim([-10 10]);
colormap jet
shading flat
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
xlabel("c_3")
ylabel("c_2")
xlim([1 15]);
ylim([-10,-1]);
c=colorbar;
% set(gca,'colorscale','log')
c.Label.String = 'Max kinetic energy of the center unit cell';
axis square
hold on;
plot([9.65],[-5.88],'p', 'MarkerSize', 20, 'MarkerFaceColor', 'r', 'MarkerEdgeColor', 'k')
plot([11],[-6.6],'-^', 'MarkerSize', 10, 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'k')
plot([6.75],[-5.36],'s', 'MarkerSize', 10, 'MarkerFaceColor', 'm', 'MarkerEdgeColor', 'k')


%%

% log_max_c2=diff(max_kinetic_energy_end1,1,1)/diff(C2_1,1,1);
% log_max_c3=diff(max_kinetic_energy_end1,1,2)/diff(C3_1,1,2);