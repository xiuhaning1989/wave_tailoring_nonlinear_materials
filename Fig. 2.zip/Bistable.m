clear all
clc

C2=0:0.5:100;C3=logspace(-2,2,201);

for jj=1:length(C2)
    C2_matrix(1:length(C3),jj)=C2(jj);
end
for jj=1:length(C3)
    C3_matrix(jj,1:length(C2))=C3(jj);
end
[n_M,m_M]=size(C2_matrix);

for q=1:m_M
    for p=1:n_M
        c2=C2_matrix(p,q);c3=C3_matrix(p,q);
        x1(p,q)=(-2*c2-sqrt(4*c2^2-12*c3))/(6*c3);
        x2(p,q)=(-2*c2+sqrt(4*c2^2-12*c3))/(6*c3);
        f1(p,q)=x1(p,q)+c2*x1(p,q)^2+c3*x1(p,q)^3;
        f2(p,q)=x2(p,q)+c2*x2(p,q)^2+c3*x2(p,q)^3;
    end
end



figure;pcolor(C3_matrix,C2_matrix,real(abs(f1)-abs(f2)))
% set(gca,'colorscale','log')
% set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
% caxis([1e-2 upper_limit]);
colormap jet
xlabel("c_3")
ylabel("c_2")
% xlim([1 200]);
% ylim([-100 100]);
% set(gca,'colorscale','log')
c=colorbar;
% c.Label.String = 'Max kinetic energy of the center unit cell';
shading flat
axis equal
axis square

