clear all;
clc

%%%%%%%%%%%%%%%%%%
c01=1;
% c02=-2.2703;
% c03=5.0588;
% c02=-6;
% c03=8.6;
c03=9.65;
c02=-5.88;

% c01=1;
% c03=-4;
% c02=-5;
L=1;
x=linspace(0*L,0.8*L,50);
i=1;j=1;
x1=(-2*c02(j)-sqrt(4*c02(j)^2-12*c01*c03(i)))/(6*c03(i))
x2=(-2*c02(j)+sqrt(4*c02(j)^2-12*c01*c03(i)))/(6*c03(i))
y=c01*x+c02(j)*x.^2+c03(i)*x.^3;
figure;
plot(x,y,'b-',"LineWidth",2)


c03=11;
c02=-6.6;
x1=(-2*c02(j)-sqrt(4*c02(j)^2-12*c01*c03(i)))/(6*c03(i))
x2=(-2*c02(j)+sqrt(4*c02(j)^2-12*c01*c03(i)))/(6*c03(i))
y2=c01*x+c02(j)*x.^2+c03(i)*x.^3;
hold on;
plot(x,y2,'r-',"LineWidth",2)
grid on;

c03=6.7523;
c02=-5.2592;
y3=c01*x+c02(j)*x.^2+c03(i)*x.^3;
hold on;
plot(x,y3,'g-',"LineWidth",2)
grid on;

c01=1;
c02 = -4.7084;
c03 = 1.9736;
c04 = 17.7426;
c05 = -15.0476;

% x=linspace(-1*L,1*L,100);
y4=c01*x+c02(j)*x.^2+c03(i)*x.^3+c04(j)*x.^4+c05(i)*x.^5;
plot(x,y4,'k--',"LineWidth",2)
grid on;
