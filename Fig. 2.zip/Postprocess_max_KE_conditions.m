clear all;
clc

load m05v1_zeta001.mat

upper_limit=10;

max_kinetic_energy_mid1=max_kinetic_energy_mid(1:81,:)/0.0364557763080379;
max_kinetic_energy_mid2=max_kinetic_energy_mid(82:end,:)/0.0364557763080379;

max_kinetic_energy_end1=max_kinetic_energy_end(1:81,:)/0.0364557763080379;
max_kinetic_energy_end2=max_kinetic_energy_end(82:end,:)/0.0364557763080379;


logC3_1=log10(C3_1);logC3_2=log10(C3_2);
logC2_1=log10(C2_1);logC2_2=log10(C2_2(2:end,:));
C21=-10.^logC2_1;


logC3=[logC3_1;logC3_2];logC2=[logC2_1;C2_2(1,:);logC2_2];

%%
figure;pcolor(C3_1,C2_1,max_kinetic_energy_mid1)
caxis([1e-2 upper_limit]);
colormap jet
shading flat
set(gca,'colorscale','log')
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
xlabel("c_3")
ylabel("c_2")
xlim([0.1,1e4]);
ylim([-1e4,-0.1]);
c=colorbar;
set(gca,'colorscale','log')
c.Label.String = 'Max kinetic energy of the center unit cell';
axis equal
axis square
figure;pcolor(C3_2,C2_2,max_kinetic_energy_mid2)
set(gca,'colorscale','log')
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
caxis([1e-2 upper_limit]);
colormap jet
xlabel("c_3")
ylabel("c_2")
xlim([0.1,1e4]);
ylim([0.1,1000]);
% set(gca,'colorscale','log')
c=colorbar;
c.Label.String = 'Max kinetic energy of the center unit cell';
shading flat
axis equal
axis square


figure;pcolor(C3_1,C2_1,max_kinetic_energy_end1)
clim([1e-2 3]);
colormap jet
shading flat
set(gca,'colorscale','log')
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
xlabel("c_3")
ylabel("c_2")
xlim([1 15]);
ylim([-10,-1]);
c=colorbar;
set(gca,'colorscale','log')
c.Label.String = 'Max kinetic energy of the center unit cell';
axis equal
axis square
figure;pcolor(C3_2,C2_2,max_kinetic_energy_end2)
set(gca,'colorscale','log')
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
caxis([1e-2 upper_limit]);
colormap jet
xlabel("c_3")
ylabel("c_2")
xlim([0.1,1e4]);
ylim([0.1,1000]);
% set(gca,'colorscale','log')
c=colorbar;
c.Label.String = 'Max kinetic energy of the center unit cell';
shading flat
axis equal
axis square