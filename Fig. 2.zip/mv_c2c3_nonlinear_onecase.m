clc;
clear all;
close all;


% load c2_c3_data_N20.mat
%% Initialize the required input parameters (Unit: m)
% Quadrant on which the stress-strain curve is defined
a=0.125;
k1=1000;
k2=1000;
m1=400e-3;
m2=400e-3;
c_non=a*sqrt(k1/m1);
c_lin=a*sqrt(k2/m2);

mass_physical=40e-3;
M_impactor1=0.5;%mass_physical/m1;
M_impactor2=0.5;%mass_physical/m2;
velocity_physical=1.37;
V_impactor1=1;%velocity_physical/c_non;
V_impactor2=1;%(velocity_physical+0.0)/c_lin;

% M_impactor1=0.1;M_impactor2=0.1;
% mass_physical=[M_impactor1*m1 M_impactor2*m2];
% V_impactor1=0.2202;V_impactor2=0.2202;
% velocity_physical=[V_impactor1*c_non V_impactor2*c_lin];

N = 20;                      % number of layers per samplheight
m_layer=1;
M0_impactor=N/2;
C_impact =1.2e4; %C_impact1/(a1*K_layer_Linear1)*a1^1.5;

zeta_bis=0.01;       % nondimensional viscous damping parameter
zeta_lin=0.01; 

C3=9.6463;
C2=-5.8818;
C1=1;
% 
C3=11;
C2=-6.6;
% C2 = -6;
% C3 = 8.6;

% c03=8.6;
% C3=6.7523;
% C2=-5.2592;
% Setup the options for ode45 solver
% C2 = -4.7084;
% C3 = 1.9736;
% C4 = 17.7426;
% C5 = -15.0476;


x1=(-2*C2-sqrt(4*C2^2-12*C1*C3))/(6*C3)
x2=(-2*C2+sqrt(4*C2^2-12*C1*C3))/(6*C3)

options_ode45 = [];
options2 = odeset('RelTol',1e-10,'AbsTol',1e-10.*ones(1,2*(N+1)));

k_f=max(1,1+2*C2+3*C3);%+4*C4+5*C5);
f0 = 1/(2*pi)*sqrt(1/M0_impactor);
dt_cyc0 = 1/f0;
cycles = 5;
outputpercycle = 500;
f = 1/(2*pi)*sqrt(k_f/M0_impactor);
dt_cyc = 1/f;
dt = dt_cyc/outputpercycle;
T = dt_cyc0*cycles;
downsample = 1e+1;
time_range = [0 T];

material_info=[m_layer M_impactor1 C_impact zeta_bis];
initialvals = zeros(2*(N+1),1);
initialvals(2) = V_impactor1;
nonlinear_spring_info = [C1 C2 C3];
% nonlinear_spring_info = [C1 C2 C3 C4 C5];
% [t, X_non] = ode45(@(t,x) impact_equation_of_motion_asymetric5th(t,x,...
%             nonlinear_spring_info,material_info,0),0:dt:T, initialvals, options2);

[t, X_non] = ode45(@(t,x) impact_equation_of_motion_asymetric(t,x,...
            nonlinear_spring_info,material_info,0),0:dt:T, initialvals, options2);
velocity_x_non=X_non(:,2:2:2*(N+1));
displacement_x_non=X_non(:,1:2:2*(N+1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
initialvals = zeros(2*(N+1),1); 
initialvals(2) = V_impactor2;
material_info=[m_layer M_impactor2 C_impact zeta_lin];
nonlinear_spring_info = [C1 0 0];
[t, X_lin] = ode45(@(t,x) impact_equation_of_motion_asymetric(t,x,...
    nonlinear_spring_info,material_info,0),0:dt:T, initialvals, options2);
velocity_x_lin=X_lin(:,2:2:2*(N+1));
displacement_x_lin=X_lin(:,1:2:2*(N+1));
% 



Relative_disp_non=displacement_x_non(:,2:N+1)-displacement_x_non(:,1:N);
Relative_disp_non(:,N+1)=0-displacement_x_non(:,N+1);
max_relative_disp_non=max(max((Relative_disp_non(:,2:end))))
min(min((Relative_disp_non(:,2:end))))

Relative_disp_lin=displacement_x_lin(:,2:N+1)-displacement_x_lin(:,1:N);
Relative_disp_lin(:,N+1)=0-displacement_x_lin(:,N+1);
max_relative_disp_lin=max(max((Relative_disp_lin(:,2:end))))
min(min((Relative_disp_lin(:,2:end))))

%%
Kinetic_energy_non=1/2*(c_non*velocity_x_non).^2*m1;
Kinetic_energy_lin=1/2*(c_lin*velocity_x_lin).^2*m2;

figure;plot(t/sqrt(k2/m2),Kinetic_energy_lin(:,N/2),'r-','linewidth',1.2)
ylabel('Kinetic (J)');
xlabel('Time (s)');

% for ii = 1:20
%     max_kinetic_energy_lin(ii)=max(Kinetic_energy_lin(:,ii+1));
%     max_kinetic_energy_non(ii)=max(Kinetic_energy_non(:,ii+1));
% end
% figure;plot(1:N,max_kinetic_energy_lin./max_kinetic_energy_non,'r-o', LineWidth=2,MarkerSize=6)
% xlabel('Number of unit cell');
% ylabel('KE ratio of Linear/Bistable');
% grid on;

Relative_disp_non(:,N+2)=NaN;
figure;pcolor(1:N+1,t/sqrt(k1/m1),Relative_disp_non(:,2:end))
shading flat
colormap jet
clim([-0.5,0.2])
xlabel('Number of unit cell');
ylabel('Time (s)');
c=colorbar;
% ylim([0 0.5])
% set(gca,'colorscale','log')
c.Label.String = 'Strain';

Relative_disp_lin(:,N+2)=NaN;
figure;pcolor(1:N+1,t/sqrt(k1/m1),Relative_disp_lin(:,2:end))
shading flat
colormap jet
clim([-0.5,0.2])
xlabel('Number of unit cell');
ylabel('Time (s)');
c=colorbar;
% ylim([0 0.5])
% set(gca,'colorscale','log')
c.Label.String = 'Strain';

velocity_x_non(:,N+2)=NaN;
figure;pcolor(1:N+1,t/sqrt(k1/m1),0.5*m_layer*(velocity_x_non(:,2:end)).^2/(0.5*M_impactor1*V_impactor1^2))
shading flat
colormap parula
clim([0.0001 1])
xlabel('Number of unit cell');
ylabel('Time (s)')
title 'Kinetic Energy vs Time'
c=colorbar;
% ylim([0 0.5])
set(gca,'colorscale','log')
c.Label.String = 'KE/TE';

velocity_x_lin(:,N+2)=NaN;
figure;pcolor(1:N+1,t/sqrt(k2/m2),0.5*m_layer*(velocity_x_lin(:,2:end)).^2/(0.5*M_impactor2*V_impactor2^2))
shading flat
colormap parula
clim([0.0001 1])
xlabel('Number of unit cell');
ylabel('Time (s)');
title 'Kinetic Energy vs Time'
c=colorbar;
% ylim([0 0.5])
set(gca,'colorscale','log')
c.Label.String = 'KE/TE';

%%
displacement_x=displacement_x_lin;
nonlinear_spring_info = [C1 0 0];
for i=1:N+1
    
    for j=1:length(t)
        if i==1
            if displacement_x(j,i)>displacement_x(j,i+1)
                potential_energy(j,i)=C_impact*2/5*(displacement_x(j,i)-displacement_x(j,i+1)).^2.5;
            else
                potential_energy(j,i)=0;
            end
        elseif i==N+1
            if 0>=displacement_x(j,i)
                potential_energy(j,i)=nonlinear_spring_info(1)/2*(0-displacement_x(j,i)).^2+...
                    nonlinear_spring_info(2)/3*(0-displacement_x(j,i)).^3+...
                    nonlinear_spring_info(3)/4*(0-displacement_x(j,i)).^4;
            else
                potential_energy(j,i)=nonlinear_spring_info(1)/2*(0-displacement_x(j,i)).^2-...
                    nonlinear_spring_info(2)/3*(0-displacement_x(j,i)).^3+...
                    nonlinear_spring_info(3)/4*(0-displacement_x(j,i)).^4;
            end
        else
            if displacement_x(j,i+1)>=displacement_x(j,i)
                potential_energy(j,i)=nonlinear_spring_info(1)/2*(displacement_x(j,i+1)-displacement_x(j,i)).^2+...
                    nonlinear_spring_info(2)/3*(displacement_x(j,i+1)-displacement_x(j,i)).^3+...
                    nonlinear_spring_info(3)/4*(displacement_x(j,i+1)-displacement_x(j,i)).^4;
            else
                potential_energy(j,i)=nonlinear_spring_info(1)/2*(displacement_x(j,i+1)-displacement_x(j,i)).^2-...
                    nonlinear_spring_info(2)/3*(displacement_x(j,i+1)-displacement_x(j,i)).^3+...
                    nonlinear_spring_info(3)/4*(displacement_x(j,i+1)-displacement_x(j,i)).^4;
            end
        end
    end
end
potential_energy_lin=potential_energy;


displacement_x=displacement_x_non;
nonlinear_spring_info = [C1 C2 C3];
for i=1:N+1
    
    for j=1:length(t)
        if i==1
            if displacement_x(j,i)>displacement_x(j,i+1)
                potential_energy(j,i)=C_impact*2/5*(displacement_x(j,i)-displacement_x(j,i+1)).^2.5;
            else
                potential_energy(j,i)=0;
            end
        elseif i==N+1
            if 0>=displacement_x(j,i)
                potential_energy(j,i)=nonlinear_spring_info(1)/2*(0-displacement_x(j,i)).^2+...
                    nonlinear_spring_info(2)/3*(0-displacement_x(j,i)).^3+...
                    nonlinear_spring_info(3)/4*(0-displacement_x(j,i)).^4;
            else
                potential_energy(j,i)=nonlinear_spring_info(1)/2*(0-displacement_x(j,i)).^2-...
                    nonlinear_spring_info(2)/3*(0-displacement_x(j,i)).^3+...
                    nonlinear_spring_info(3)/4*(0-displacement_x(j,i)).^4;
            end
        else
            if displacement_x(j,i+1)>=displacement_x(j,i)
                potential_energy(j,i)=nonlinear_spring_info(1)/2*(displacement_x(j,i+1)-displacement_x(j,i)).^2+...
                    nonlinear_spring_info(2)/3*(displacement_x(j,i+1)-displacement_x(j,i)).^3+...
                    nonlinear_spring_info(3)/4*(displacement_x(j,i+1)-displacement_x(j,i)).^4;
            else
                potential_energy(j,i)=nonlinear_spring_info(1)/2*(displacement_x(j,i+1)-displacement_x(j,i)).^2-...
                    nonlinear_spring_info(2)/3*(displacement_x(j,i+1)-displacement_x(j,i)).^3+...
                    nonlinear_spring_info(3)/4*(displacement_x(j,i+1)-displacement_x(j,i)).^4;
            end
        end
    end
end
potential_energy_non=potential_energy;


potential_energy_non(:,N+2)=NaN;
figure;pcolor(1:N+1,t/sqrt(k1/m1),potential_energy_non(:,2:end)/(0.5*M_impactor1*V_impactor1^2))
shading flat
colormap jet
clim([0.0001 1])
xlabel('Number of unit cell');
ylabel('Time (s)')
title 'Potential Energy vs Time'
c=colorbar;
% ylim([0 0.5])
set(gca,'colorscale','log')
c.Label.String = 'PE/TE';

potential_energy_lin(:,N+2)=NaN;
figure;pcolor(1:N+1,t/sqrt(k2/m2),potential_energy_lin(:,2:end)/(0.5*M_impactor2*V_impactor2^2))
shading flat
colormap jet
clim([0.0001 1])
xlabel('Number of unit cell');
ylabel('Time (s)');
title 'Potential Energy vs Time'
c=colorbar;
% ylim([0 0.5])
set(gca,'colorscale','log')
c.Label.String = 'PE/TE';

%%


% figure;
% startColor = [1,0.2,0.2]; endColor=[0,0,1];
% for ii = 1:20
%     plot(t/sqrt(k1/m), a*displacement_x_non(1:1:length(t),ii),'Color',startColor + (endColor-startColor)*(ii-1) /19,linewidth=2);
%     hold on;
% end
% xlabel('Time/s');
% ylabel('Displacement/m');
% % legend('1st','2nd','3rd','4th')
% grid on;
% 
% figure;
% startColor = [1,0.2,0.2]; endColor=[0,0,1];
% for ii = 1:20
%     plot(t/sqrt(k1/m), c0*velocity_x_non(1:1:length(t),ii),'Color',startColor + (endColor-startColor)*(ii-1) /19,linewidth=2);
%     hold on;
% end
% xlabel('Time/s');
% ylabel('Velocity/ms^{-1}');
% % legend('1st','2nd','3rd','4th')
% grid on;
% 
% 
% %%
% 
% figure;
% startColor = [1,0.2,0.2]; endColor=[0,0,1];
% for ii = 1:20
%     plot(t/sqrt(k1/m), a*displacement_x_lin(1:1:length(t),ii),'Color',startColor + (endColor-startColor)*(ii-1) /19,linewidth=2);
%     hold on;
% end
% xlabel('Time/s');
% ylabel('Displacement/m');
% % legend('1st','2nd','3rd','4th')
% grid on;
% 
% figure;
% startColor = [1,0.2,0.2]; endColor=[0,0,1];
% for ii = 1:20
%     plot(t/sqrt(k1/m), c0*velocity_x_lin(1:1:length(t),ii),'Color',startColor + (endColor-startColor)*(ii-1) /19,linewidth=2);
%     hold on;
% end
% xlabel('Time/s');
% ylabel('Velocity/ms^{-1}');
% % legend('1st','2nd','3rd','4th')
% grid on;


