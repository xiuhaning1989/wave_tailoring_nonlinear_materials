

Relative_disp_non(:,N+2)=NaN;
% Relative_disp_nonpos=zeros(length(t),N+2);
% Relative_disp_nonneg=zeros(length(t),N+2);
% Relative_disp_linpos=zeros(length(t),N+2);
% Relative_disp_linneg=zeros(length(t),N+2);
% 
% for i=1:N+1    
%     for j=1:length(t)
%         if Relative_disp_non(j,i)>=0
%             Relative_disp_nonpos(j,i)=Relative_disp_non(j,i);
%             Relative_disp_nonneg(j,i)=NaN;
%         else
%             Relative_disp_nonneg(j,i)=Relative_disp_non(j,i);
%             Relative_disp_nonpos(j,i)=NaN;
%         end
%         if Relative_disp_lin(j,i)>=0
%             Relative_disp_linpos(j,i)=Relative_disp_lin(j,i);
%             Relative_disp_linneg(j,i)=NaN;
%         else
%             Relative_disp_linneg(j,i)=Relative_disp_lin(j,i);
%             Relative_disp_linpos(j,i)=NaN;
%         end
%     end
% end


negColors = [linspace(0, 1, 60)' linspace(0, 1, 60)' ones(60, 1)];
posColors = [ones(130, 1) linspace(1, 0, 130)' linspace(1, 0, 130)'];
customColormap = [negColors; posColors];

cmap_pos = autumn(130);  % For positive values (summer colormap)
cmap_neg = summer(60);  % For negative values (autumn colormap)
cmap = [cmap_neg; flipud(cmap_pos)];

figure;pcolor(1:N+1,t/sqrt(k1/m1),-Relative_disp_non(:,2:end))
shading flat
colormap(customColormap)
clim([-0.3,0.65])
xlabel('Number of unit cell');
ylabel('Time (s)');
c=colorbar;
% ylim([0 0.5])
% set(gca,'colorscale','log')
c.Label.String = 'Strain';
axis square
Relative_disp_lin(:,N+2)=NaN;
figure;pcolor(1:N+1,t/sqrt(k1/m1),-Relative_disp_lin(:,2:end))
shading flat
colormap(customColormap)
clim([-0.3,0.65])
xlabel('Number of unit cell');
ylabel('Time (s)');
c=colorbar;
% ylim([0 0.5])
% set(gca,'colorscale','log')
c.Label.String = 'Strain';
axis square