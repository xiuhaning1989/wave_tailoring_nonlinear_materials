clear all
clc

load m1v1_zeta001N=50.mat
filename1 = 'm1v1_zeta001N=50_nonlinear.gif';

atom=(0:49).*ones(length(t),N);
%%
T=t(1:fix(length(t)/426):fix(length(t)/426)*320);
x_unit=atom+displacement_x_non(:,2:end);
y_unit=(0:49).*zeros(length(t),N);
% y_unit=atom(:,4)'+displacement_y_non;
% phi_unit=atom(:,5)'+displacement_rotation_non;              
% Kinetic_energy=0.5*mass*(velocity_x_non.^2+velocity_y_non.^2)+0.5*Inertia*velocity_rotation_non.^2;

figure(1)
% colormap jet;
% set(gcf, 'position', [50 50 2550 750]);%[50 50 2550 200]
% M = moviein(length(T));
for tt=1:length(T) 
    time0=find(abs(t-T(tt))<1e-5);

    Kinetic_energy=0.5*m_layer*velocity_x_non(time0,2:end-1).^2;
    
%     plot(atom(:,3),atom(:,4),'o--','Color', 'y','MarkerEdgeColor', [0.7 0.7 0.7], 'LineWidth', 0.5, 'MarkerSize', 5,'MarkerFaceColor',[0.7 0.7 0.7]);hold on;
    plot(0,0);hold on;
%     Z = zeros(size(X)) ;                %// Z plane = 0
%     plot(X,Y,'k-','LineWidth',0.75);
%     surf(X,Y,Z,C_shear,'EdgeColor','flat','FaceColor','none','LineWidth',2);
%     surf(X,Y,Z,C_normal,'EdgeColor','flat','FaceColor','none','LineWidth',2);
%     cmap_pos = autumn(60);  % For positive values (summer colormap)
%     cmap_neg = summer(60);  % For negative values (autumn colormap)
%     cmap = [cmap_neg; flipud(cmap_pos)];
%     colormap (cmap)
   set(gcf, 'position', [50 50 1500 80]);
%     scatter(x_unit(time0,:),y_unit(time0,:),27,velocity_x_non(time0,:),'filled');
    scatter(x_unit(time0,:),y_unit(time0,:),280,Kinetic_energy/(0.5*M_impactor2*V_impactor2^2),'square','filled');
    colormap jet
    c=colorbar;
    xlim([-5 80])
    ylim([-0.5 0.5]) 
    clim([1e-4,1])
    c.Label.String = 'KE/TE';
    set(gca,'colorscale','log')
    hold off;
%     axis equal  
    grid on;

    

%     text(8,52,['Time = ' num2str(T(tt),'%.2f')],'FontSize',14)
    text(35,0.4,['Time = ' num2str(T(tt)/N,'%.2f')],'FontSize',10)
    f1 = getframe(gcf); 
        imind1 = frame2im(f1); 
        [imind1,cm1] = rgb2ind(imind1,256); 
    if tt == 1 
        imwrite(imind1,cm1,filename1,'gif', 'Loopcount',500,'DelayTime',0); 
    else
        imwrite(imind1,cm1,filename1,'gif','WriteMode','append','DelayTime',0.1);
    end

end


filename1 = 'm1v1_zeta001N=50_linear.gif';
x_unit=atom+displacement_x_lin(:,2:end);
y_unit=(0:49).*zeros(length(t),N);
figure(2)
% colormap jet;
% set(gcf, 'position', [50 50 2550 750]);%[50 50 2550 200]
% M = moviein(length(T));
for tt=1:length(T) 
    time0=find(abs(t-T(tt))<1e-5);

    Kinetic_energy=0.5*m_layer*velocity_x_lin(time0,2:end-1).^2;
    
%     plot(atom(:,3),atom(:,4),'o--','Color', 'y','MarkerEdgeColor', [0.7 0.7 0.7], 'LineWidth', 0.5, 'MarkerSize', 5,'MarkerFaceColor',[0.7 0.7 0.7]);hold on;
    plot(0,0);hold on;
%     Z = zeros(size(X)) ;                %// Z plane = 0
%     plot(X,Y,'k-','LineWidth',0.75);
%     surf(X,Y,Z,C_shear,'EdgeColor','flat','FaceColor','none','LineWidth',2);
%     surf(X,Y,Z,C_normal,'EdgeColor','flat','FaceColor','none','LineWidth',2);
%     cmap_pos = autumn(60);  % For positive values (summer colormap)
%     cmap_neg = summer(60);  % For negative values (autumn colormap)
%     cmap = [cmap_neg; flipud(cmap_pos)];
%     colormap (cmap)
   set(gcf, 'position', [50 50 1500 80]);
%     scatter(x_unit(time0,:),y_unit(time0,:),27,velocity_x_non(time0,:),'filled');
    scatter(x_unit(time0,:),y_unit(time0,:),280,Kinetic_energy/(0.5*M_impactor2*V_impactor2^2),'square','filled');
    colormap jet
    c=colorbar;
    xlim([-5 80])
    ylim([-0.5 0.5]) 
    clim([1e-4,1])
    c.Label.String = 'KE/TE';
    set(gca,'colorscale','log')
    hold off;
%     axis equal  
    grid on;

    

%     text(8,52,['Time = ' num2str(T(tt),'%.2f')],'FontSize',14)
    text(35,0.4,['Time = ' num2str(T(tt)/N,'%.2f')],'FontSize',10)
    f1 = getframe(gcf); 
        imind1 = frame2im(f1); 
        [imind1,cm1] = rgb2ind(imind1,256); 
    if tt == 1 
        imwrite(imind1,cm1,filename1,'gif', 'Loopcount',500,'DelayTime',0); 
    else
        imwrite(imind1,cm1,filename1,'gif','WriteMode','append','DelayTime',0.15);
    end

end















