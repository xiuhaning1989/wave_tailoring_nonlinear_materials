clear all;
close all;
clc

% load mv_linear.mat
load mv_zeta0005_V_1_36_N20.mat
load mv_zeta0005_linear_N20.mat

mv_minmax_kinetic_energy_nonlinear=mv_minmax_kinetic_energy_all1;
mv_minmax_kinetic_linear=mv_minmax_kinetic_energy_linear1;
% mv_minmax_kinetic_linear1=mv_minmax_kinetic_energy_linear1;
mv_C3_all=mv_C3_all1;
mv_C2_all=mv_C2_all1;

figure;plot(reshape(mv_C3_all1,[],1),'k*',markersize=3);ylim([150 250])
figure;plot(reshape(mv_C2_all1,[],1),'b*',markersize=3);ylim([-40 -20])

% mv_minmax_kinetic_energy_all=mv_minmax_kinetic_energy_all2;
% mv_minmax_kinetic_linear=mv_minmax_kinetic_energy2;
% mv_minmax_kinetic_linear1=mv_minmax_kinetic_energy_linear2;
% mv_C3_all=mv_C3_all2;
% mv_C2_all=mv_C2_all2;
%%
for q=1:m_M_imp
    for p=1:n_M_imp
        if Self_contact(p,q)==1 || Reach_to_last_unitcell(p,q)==0
            mv_minmax_kinetic_linear(p,q)=NaN;
            mv_minmax_kinetic_energy_nonlinear(p,q)=NaN;
        end
    end
end

for q=1:m_M_imp
    for p=1:n_M_imp
        if mv_minmax_kinetic_linear(p,q)>0
            M_imp(q)=M_imp_matrix_all(p,q);
            V_imp(q)=V_imp_matrix_all(p,q);
        end
    end
end



%%
figure;pcolor(M_imp_matrix_all/M0_impactor,V_imp_matrix_all,mv_minmax_kinetic_energy_all1./mv_minmax_kinetic_energy_linear1)
caxis([0.1 1]);
xlim([1e-2 1]);
ylim([1e-1 1e1])
colormap jet
shading flat
set(gca,'colorscale','log')
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
xlabel("M")
ylabel("V")
c=colorbar;
axis square
c.Label.String = 'Ratio of Max mid-point kinetic energy of nonlinear and linear spring';
hold on;plot(M_imp/M0_impactor,smooth(V_imp),'w-','linewidth',2)

KEratio=mv_minmax_kinetic_linear./mv_minmax_kinetic_energy_nonlinear;

figure;pcolor(M_imp_matrix_all/M0_impactor,V_imp_matrix_all,mv_minmax_kinetic_energy_nonlinear./mv_minmax_kinetic_linear)
caxis([1e-1 1]);
xlim([1e-2 1]);
ylim([1e-1 1e1])
colormap jet
shading flat
set(gca,'colorscale','log')
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
xlabel("M")
ylabel("V")
c=colorbar;
axis square
c.Label.String = 'Ratio of Max mid-point kinetic energy of nonlinear and linear spring';

%%
[n_C2,m_C2]=size(mv_C2_all);
mv_C2_all_pos=zeros(n_C2,m_C2);
mv_C2_all_neg=zeros(n_C2,m_C2);
% mv_C2_all1=mv_C2_all;mv_C3_all1=mv_C3_all;
for j=1:m_C2
    for i=1:n_C2
        if mv_C2_all(i,j)>=0
            mv_C2_all_pos(i,j)=mv_C2_all(i,j);
            mv_C2_all_neg(i,j)=NaN;
        else
            mv_C2_all_neg(i,j)=mv_C2_all(i,j);
            mv_C2_all_pos(i,j)=NaN;
        end
    end
end
% 
% for j=1:m_C2
%     for i=1:n_C2
%         if isnan(mv_minmax_kinetic_energy1(i,j))
%             mv_C2_all1(i,j)=NaN;
%             mv_C3_all1(i,j)=NaN;
%         end
%         if mv_C2_all1(i,j)>=0
%             mv_C2_all1(i,j)=NaN;
%         end
%     end
% end


figure;pcolor(M_imp_matrix_all/M0_impactor,V_imp_matrix_all,mv_C2_all_pos)
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
xlim([1e-2 1]);
ylim([1e-1 1e1])
% caxis([-30 50]);
colormap(flipud(autumn))
% colormap jet
xlabel("M")
ylabel("V")
set(gca,'colorscale','log')
c=colorbar;
% caxis([1e0 1e3]);
caxis([1,1000])
% c.Label.String = 'Max kinetic energy of the center unit cell';
shading flat
axis square

figure;pcolor(M_imp_matrix_all/M0_impactor,V_imp_matrix_all,mv_C2_all_neg)
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
xlim([1e-2 1]);
ylim([1e-1 1e1])
% caxis([-30 50]);
colormap(summer)
xlabel("M")
ylabel("V")
set(gca,'colorscale','log')
c=colorbar;
caxis([-100 -1]);
% c.Label.String = 'Max kinetic energy of the center unit cell';
shading flat
axis square



%%
figure;pcolor(M_imp_matrix_all/M0_impactor,V_imp_matrix_all,mv_C3_all)
% set(gca,'colorscale','log')
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');
xlim([1e-2 1]);
ylim([1e-1 1e1])
caxis([1e-1 1e4])
colormap(flipud(autumn))
% colormap jet
xlabel("M")
ylabel("V")
set(gca,'colorscale','log')
c=colorbar;
% c.Label.String = 'Max kinetic energy of the center unit cell';
shading flat
 axis square


