% M_imp_matrix_all=[];
% mv_C2_all1=[];
% mv_C3_all1=[];
% mv_minmax_kinetic_energy_all1=[];
% V_imp_matrix_all=[];
% mv_C2_all2=[];
% mv_C3_all2=[];
% mv_minmax_kinetic_energy_all2=[];
% mv_C2_all3=[];
% mv_C3_all3=[];
% mv_minmax_kinetic_energy_all3=[];


%%
M_imp_matrix_all=[M_imp_matrix_all;M_imp_matrix];
mv_C2_all1=[mv_C2_all1;mv_C21];
mv_C3_all1=[mv_C3_all1;mv_C31];
mv_C2_all2=[mv_C2_all2;mv_C22];
mv_C3_all2=[mv_C3_all2;mv_C32];
mv_C2_all3=[mv_C2_all3;mv_C23];
mv_C3_all3=[mv_C3_all3;mv_C33];
mv_minmax_kinetic_energy_all1=[mv_minmax_kinetic_energy_all1;mv_minmax_kinetic_energy1];
V_imp_matrix_all=[V_imp_matrix_all;V_imp_matrix];
mv_minmax_kinetic_energy_all2=[mv_minmax_kinetic_energy_all2;mv_minmax_kinetic_energy2];
mv_minmax_kinetic_energy_all3=[mv_minmax_kinetic_energy_all3;mv_minmax_kinetic_energy3];



% save('mv_zeta0005_V_1_36.mat')


















